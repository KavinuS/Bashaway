#include <stdio.h>

int main() {
    printf("Greetings from the phantom realm!\n");
    printf("The compilation was successful.\n");
    return 0;
}

