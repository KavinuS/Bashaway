#!/bin/bash

# Black-flagged gatehouse orchestrator
# Creates nginx configuration for reverse proxy with TLS termination,
# load balancing, health checks, rate limiting, and custom error pages

set -e

# Create output directory
mkdir -p out
mkdir -p out/html
mkdir -p out/ssl

# Generate self-signed SSL certificate for TLS termination
if [ ! -f out/ssl/cert.pem ] || [ ! -f out/ssl/key.pem ]; then
    openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
        -keyout out/ssl/key.pem \
        -out out/ssl/cert.pem \
        -subj "/C=US/ST=State/L=City/O=BlackFlag/CN=gatehouse" 2>/dev/null || {
        # Fallback if openssl not available - create dummy files
        echo "Warning: openssl not available, creating placeholder certs"
        touch out/ssl/cert.pem out/ssl/key.pem
    }
fi

# Create custom error pages
cat > out/html/404.html << 'EOF'
<!DOCTYPE html>
<html>
<head>
    <title>404 - Ship Not Found</title>
    <style>
        body { font-family: monospace; background: #000; color: #0f0; text-align: center; padding: 50px; }
        h1 { font-size: 3em; }
        p { font-size: 1.2em; }
    </style>
</head>
<body>
    <h1>⚓ 404 - Ship Not Found</h1>
    <p>The vessel you seek has sailed beyond these waters.</p>
</body>
</html>
EOF

cat > out/html/500.html << 'EOF'
<!DOCTYPE html>
<html>
<head>
    <title>500 - Storm at Sea</title>
    <style>
        body { font-family: monospace; background: #000; color: #f00; text-align: center; padding: 50px; }
        h1 { font-size: 3em; }
        p { font-size: 1.2em; }
    </style>
</head>
<body>
    <h1>🌊 500 - Storm at Sea</h1>
    <p>The galleons have been struck by a tempest. The quartermaster is working to restore order.</p>
</body>
</html>
EOF

cat > out/html/502.html << 'EOF'
<!DOCTYPE html>
<html>
<head>
    <title>502 - Galleon Unreachable</title>
    <style>
        body { font-family: monospace; background: #000; color: #ff0; text-align: center; padding: 50px; }
        h1 { font-size: 3em; }
        p { font-size: 1.2em; }
    </style>
</head>
<body>
    <h1>⛵ 502 - Galleon Unreachable</h1>
    <p>The backline ship has slipped beneath the waves. The gatehouse has struck it from the charts.</p>
</body>
</html>
EOF

cat > out/html/503.html << 'EOF'
<!DOCTYPE html>
<html>
<head>
    <title>503 - Harbor Overwhelmed</title>
    <style>
        body { font-family: monospace; background: #000; color: #0ff; text-align: center; padding: 50px; }
        h1 { font-size: 3em; }
        p { font-size: 1.2em; }
    </style>
</head>
<body>
    <h1>🚢 503 - Harbor Overwhelmed</h1>
    <p>The seas are boiling with too many requests. The quartermaster has hoisted the rate limit flag.</p>
</body>
</html>
EOF

# Generate nginx configuration
cat > out/nginx.conf << 'NGINX_CONF'
user nginx;
worker_processes auto;
error_log /var/log/nginx/error.log warn;
pid /var/run/nginx.pid;

events {
    worker_connections 1024;
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;
    
    log_format main '$remote_addr - $remote_user [$time_local] "$request" '
                    '$status $body_bytes_sent "$http_referer" '
                    '"$http_user_agent" "$http_x_forwarded_for"';
    
    access_log /var/log/nginx/access.log main;
    
    sendfile on;
    tcp_nopush on;
    tcp_nodelay on;
    keepalive_timeout 65;
    types_hash_max_size 2048;
    
    # Rate limiting zones - quartermaster's throttling
    limit_req_zone $binary_remote_addr zone=general_limit:10m rate=10r/s;
    limit_req_zone $binary_remote_addr zone=strict_limit:10m rate=5r/s;
    
    # Upstream block for backend galleons - load balancing with health checks
    upstream backend_fleet {
        # Backend servers (galleons) with health check parameters
        server host.docker.internal:8081 max_fails=3 fail_timeout=30s;
        server host.docker.internal:8082 max_fails=3 fail_timeout=30s;
        server host.docker.internal:8083 max_fails=3 fail_timeout=30s;
        
        # Load balancing method - round robin by default
        # Health checks: max_fails=3 means 3 consecutive failures mark server as down
        # fail_timeout=30s means server is considered down for 30s after max_fails
    }
    
    # HTTP server - redirect to HTTPS (encrypted chests)
    server {
        listen 80;
        server_name gatehouse;
        
        # Redirect all HTTP to HTTPS
        return 301 https://$host$request_uri;
    }
    
    # HTTPS server - the black-flagged gatehouse
    server {
        listen 443 ssl http2;
        server_name gatehouse;
        
        # TLS termination - cracking encrypted chests
        ssl_certificate /etc/nginx/ssl/cert.pem;
        ssl_certificate_key /etc/nginx/ssl/key.pem;
        ssl_protocols TLSv1.2 TLSv1.3;
        ssl_ciphers HIGH:!aNULL:!MD5;
        ssl_prefer_server_ciphers on;
        
        # Custom error pages - hand-drawn error banners
        error_page 404 /404.html;
        error_page 500 /500.html;
        error_page 502 /502.html;
        error_page 503 /503.html;
        
        location = /404.html {
            root /etc/nginx/html;
            internal;
        }
        
        location = /500.html {
            root /etc/nginx/html;
            internal;
        }
        
        location = /502.html {
            root /etc/nginx/html;
            internal;
        }
        
        location = /503.html {
            root /etc/nginx/html;
            internal;
        }
        
        # Main location - forward to backend fleet
        location / {
            # Rate limiting - quartermaster's throttling
            limit_req zone=general_limit burst=20 nodelay;
            
            # Proxy settings - forward plain cargo to galleons
            proxy_pass http://backend_fleet;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
            
            # Timeouts
            proxy_connect_timeout 10s;
            proxy_send_timeout 30s;
            proxy_read_timeout 30s;
            
            # Health check headers
            proxy_next_upstream error timeout invalid_header http_500 http_502 http_503;
            proxy_next_upstream_tries 3;
            proxy_next_upstream_timeout 10s;
        }
        
        # Strict rate limiting for specific paths
        location /api/ {
            limit_req zone=strict_limit burst=10 nodelay;
            
            proxy_pass http://backend_fleet;
            proxy_set_header Host $host;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
            proxy_set_header X-Forwarded-Proto $scheme;
        }
        
        # Health check endpoint for monitoring
        location /health {
            access_log off;
            return 200 "Gatehouse operational\n";
            add_header Content-Type text/plain;
        }
    }
}
NGINX_CONF

echo "Nginx configuration generated successfully at out/nginx.conf"
echo "Custom error pages created in out/html/"
echo "SSL certificates prepared in out/ssl/"
